package org.iesalixar.servidor.isidro.dao;

import org.iesalixar.servidor.isidro.model.Offices;

public interface DAOOffices {
	
	public Offices getOffices(String city);
}
