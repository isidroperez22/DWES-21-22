package org.iesalixar.servidor.isidro.dao;

import org.iesalixar.servidor.isidro.model.Usuario;

public interface DAOUsuario {

	public Usuario getUsuario(String nombre);
	public boolean registerUsuario(Usuario usuario);
	
}
