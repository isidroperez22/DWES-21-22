package org.iesalixar.servidor.isidro.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.iesalixar.servidor.isidro.dao.DAOOfficesImpl;

/**
 * Servlet implementation class SearchOffice
 */
@WebServlet("/SearchOffice")
public class SearchOffice extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchOffice() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/view/offices.jsp").forward(request, response);;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sesion = request.getSession();
		String searchTerm = request.getParameter("busqueda");
		String oficinas = request.getParameter("oficinas");
		
		if (searchTerm!=null) {
			
			DAOOfficesImpl dao = new DAOOfficesImpl();
			request.setAttribute("productos", dao.getOffices(searchTerm));
			sesion.setAttribute("oficinas", oficinas);

			
			doGet(request,response);
			return;
		} 
		
		
		doGet(request,response);
	}
}
