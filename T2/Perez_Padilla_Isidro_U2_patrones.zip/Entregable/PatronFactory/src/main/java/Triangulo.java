
public class Triangulo extends Figura {

	public Triangulo(String color) {
		super(color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String DibujarFigura() {
		// TODO Auto-generated method stub
		return "He dibujado un triangulo " + getColor();
	}

}
