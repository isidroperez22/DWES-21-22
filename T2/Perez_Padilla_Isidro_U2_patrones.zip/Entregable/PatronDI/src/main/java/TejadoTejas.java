
public class TejadoTejas extends Tejado {
	
	public TejadoTejas() {
		super();
	}
	@Override
	public void DarSoporte() {
		super.DarSoporte();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
