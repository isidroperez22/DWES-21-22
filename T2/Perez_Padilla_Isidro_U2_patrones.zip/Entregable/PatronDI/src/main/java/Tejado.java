
public class Tejado {
		public void DarSoporte() {
			System.out.println("Doy soprte a las tejas");
		};
		@Override
		public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
		}
}
